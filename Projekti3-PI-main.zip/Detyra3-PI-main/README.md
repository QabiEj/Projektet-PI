# Detyra3-PI
Repozitori përmban raportin e projektit bashkë me kodin e funksioneve të përdorura për zgjidhjen e detyrave brenda dokumentit.
